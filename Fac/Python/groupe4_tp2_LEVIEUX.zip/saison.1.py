p = "printemps"
e = "ete"
a = "automne"
h = "hiver"

saison = input("Veuillez donner une saison :\n")

# L'utilisation de la fonction 'lower' permet au programme de reagir
# correctement que l'on rentre 'Printemps', 'PRINTEMPS' ou 'printemps'
# ce n'etait pas indispensable mais pratique

saison = saison.lower()

base_1 = "Les dates de l'" + saison + " sont "
base_2 = "Les dates du " + saison + " sont "

if (saison == p):
    print(base_2 + "du 20 mars au 19 juin") 
elif (saison == e):
    print(base_1 + "du 20 juin au 21 septembre")
elif (saison == a):
    print(base_1 + "du 22 septembre au 20 decembre")
elif (saison == h):
    print(base_1 + "du 21 decembre au 19 mars")
else:
    print(saison + " n'est pas une saison!")
